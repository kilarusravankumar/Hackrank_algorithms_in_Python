/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alarmclock;

/**
 *
 * @author prudhvi
 */
public interface Alarm {
    static final int maxClocks=2;
    
    int hrs=0;
    int mins=0;

   public void setHrs(int a);
   public int getHrs();
   public void setMins(int a);
   public int getMins();

   
    
}
