/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alarmclock;

/**
 *
 * @author prudh
 */
public class AlarmType3 implements Alarm {
     private static int hrs;
    private static int mins;
    
    public AlarmType3(int hrs, int mins) {
       
        this.hrs=hrs;
        this.hrs=mins;
    }

   @Override
    public void setHrs(int hrs) {
       this.hrs=hrs ; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getHrs() {
        return hrs; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setMins(int a) {
        this.mins=mins; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getMins() {
        return mins; //To change body of generated methods, choose Tools | Templates.
    }
     @Override
     public String toString() {
        return hrs+":"+mins;
    }
}
