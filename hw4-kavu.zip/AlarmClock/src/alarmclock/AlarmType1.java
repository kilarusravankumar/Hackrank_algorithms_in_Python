/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alarmclock;

/**
 *
 * @author prudhvi
 */
public class AlarmType1 implements Alarm{
    private static int hrs=0;
    private static  int mins=0;
    public AlarmType1(int hrs, int mins) {
        
        this.hrs=hrs;
        this.mins=mins;
    }

    @Override
    public void setHrs(int hrs) {
       this.hrs=hrs;
        
    }

    @Override
    public int getHrs() {
        return hrs;
    }

    @Override
    public void setMins(int min) {
        
                
                this.mins=min;
    }

    @Override
    public int getMins() {
        return mins; 
    }

    @Override
    public String toString() {
        return hrs+":"+mins;
    }

    }
    

